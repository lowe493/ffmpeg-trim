﻿
$files = Get-ChildItem -Path .\videos -Recurse -ErrorAction SilentlyContinue -Filter *.mkv | Where-Object { $_.Extension -eq '.mkv' }
foreach ($file in $files)
{
    .\resources\bin\ffmpeg.exe -i .\videos\$file -vcodec copy -acodec copy -ss 00:00:10 ".\output\trimmed-$file"
}

