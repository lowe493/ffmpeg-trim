﻿$trim = "10"

$files = Get-ChildItem -Path .\videos -Recurse -ErrorAction SilentlyContinue -Filter *.mkv | Where-Object { $_.Extension -eq '.mkv' }
foreach ($file in $files)
{
    $length = .\resources\bin\ffprobe.exe .\videos\$file -show_entries format=duration -v quiet -of csv="p=0"
    $length = $length - $trim
    .\resources\bin\ffmpeg.exe -i .\videos\$file -vcodec copy -acodec copy -t $length ".\output\trimmed-$file"
}